//  This is needed for the location service, see
//  https://github.com/Agontuk/react-native-geolocation-service/blob/master/docs/setup.md#2-enable-swift-support
//  enableSwiftSupport.swift
//  SwagLabsMobileApp

//  enableSwiftSupport.swift
//  
//
//  Created by Wim Selles on 01/08/2021.
//

import Foundation
