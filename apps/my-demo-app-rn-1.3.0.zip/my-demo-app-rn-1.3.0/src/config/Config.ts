import {TransitionPresets} from '@react-navigation/stack';

export const TransitionScreenOptions = {
  ...TransitionPresets.SlideFromRightIOS,
};
