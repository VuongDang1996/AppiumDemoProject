export const Colors = {
  black: '#000000',
  transparentBlack: 'rgba(0,0,0,0.5)',
  white: '#FFFFFF',
  slRed: '#E2231A',
  lightRed: '#FFECEB',
  superLightGray: 'rgba(237,237,239,0.6)',
  lightGray: '#EDEDEF',
  gray: '#6D7584',
  yellow: '#F1C40F',
  primaryBlue: '#0E75DD',
  lightBlue: '#E6F1FD',
};
