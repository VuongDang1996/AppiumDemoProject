export const DEFAULT_PIN = 1234;
export const INCORRECT_PIN = 4321;
